# BERRY Client — Obsidian website

Deploy this **site/** folder to Netlify Drop. Design uses the *exact user-uploaded black-and-silver BERRY artwork*, not AI-generated alternative branding. `assets/berry-original-space.png` is untouched.

The page is a standalone responsive HTML/CSS/JS site. The launcher and in-game previews are explicitly marked as previews, and the download button is intentionally disabled until a **Windows-tested BERRY React installer** is built and verified. It is unsafe to label an older Python build as the new React build.

After a real installer is verified, upload it to Netlify or (better) GitHub Releases and replace the disabled download button with a real release URL. Keep published checksums and a signed update channel for future automatic updates.
